from django.urls import path
# from accounts.views import (SendPasswordResetEmailView, UserChangePasswordView, UserLoginView,
#                            UserProfileView, UserRegistrationView, UserPasswordResetView, CreateMenuGrpView, UpdateMenuGrpView, UpdateMenuMasterView, CreateMenuMasterView,
#                            CreateTaskMasterView, UpdateTaskMasterView, CreateUserTaskAccessView, UpdateUserTaskAccessView, CreateFieldMasterView, UpdateFieldMasterView,
#                            CreateTaskFieldMasterView, UpdateTaskFieldMasterView, TodoListApiView, TodoDetailApiView)

from accounts.views import *

urlpatterns = [
    path('register/', UserRegistrationView.as_view(), name='register'),
    path('login/', UserLoginView.as_view(), name='login'),
    path('profile/', UserProfileView.as_view(), name='profile'),
    path('changepassword/', UserChangePasswordView.as_view(), name='changepassword'),
    path('send-reset-password-email/', SendPasswordResetEmailView.as_view(),
         name='send-reset-password-email'),
    path('reset-password/<uid>/<token>/',
         UserPasswordResetView.as_view(), name='reset-password'),

    path('menugroupmaster/', CreateMenuGroupMasterView.as_view(), name='menugroupmaster'),
    path('menugroupmaster/<int:pk>', UpdateMenuGroupMasterView.as_view(), name='menugroupmaster'),

    path('menumaster/', CreateMenuMasterView.as_view(), name='menumaster'),
    path('menumaster/<int:pk>', UpdateMenuMasterView.as_view(), name='menumaster'),

    path('taskmaster/', CreateTaskMasterView.as_view(), name='taskmaster'),
    path('taskmaster/<int:pk>/', UpdateTaskMasterView.as_view(), name='taskmaster'),

    path('usertaskaccess/', CreateUserTaskAccessView.as_view(), name='usertaskaccess'),
    path('usertaskaccess/<int:pk>/', UpdateUserTaskAccessView.as_view(), name='usertaskaccess'),

    path('fieldmaster/', CreateFieldMasterView.as_view(), name='fieldmaster'),
    path('fieldmaster/<int:pk>/', UpdateFieldMasterView.as_view(), name='fieldmaster'),

    path('taskfieldmaster/', CreateTaskFieldMasterView.as_view(), name='taskfieldmaster'),
    path('taskfieldmaster/<int:todo_id>/', UpdateTaskFieldMasterView.as_view(), name='taskfieldmaster'),

#     path('todolistapiview/', TodoListApiView.as_view(), name='todolistapiview'),
#     path('todolistapiview/<int:todo_id>/', TodoDetailApiView.as_view(), name='todolistapiview'),

]



